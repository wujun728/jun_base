package com.ruoyi.generator.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.generator.domain.GenTableColumn;
import org.apache.ibatis.annotations.Mapper;

/**
 * 业务字段 数据层
 * 
 * @author ruoyi
 */
@Mapper
public interface GenTableColumnMapper extends BaseMapper<GenTableColumn>
{
    /**
     * 根据表名称查询列信息
     *
     * @param tableName 表名称
     * @return 列信息
     */
    public List<GenTableColumn> selectDbTableColumnsByName(String tableName);

//    /**
//     * 查询业务字段列表
//     *
//     * @param tableId 业务字段编号
//     * @return 业务字段集合
//     */
//    public List<GenTableColumn> selectGenTableColumnListByTableId(Long tableId);
//
//    /**
//     * 新增业务字段
//     *
//     * @param genTableColumn 业务字段信息
//     * @return 结果
//     */
//    public int insertGenTableColumn(GenTableColumn genTableColumn);
//
//    /**
//     * 修改业务字段
//     *
//     * @param genTableColumn 业务字段信息
//     * @return 结果
//     */
//    public int updateGenTableColumn(GenTableColumn genTableColumn);
//
    /**
     * 删除业务字段
     *
     * @param genTableColumns 列数据
     * @return 结果
     */
    public int deleteGenTableColumns(List<GenTableColumn> genTableColumns);
//
//    /**
//     * 批量删除业务字段
//     *
//     * @param ids 需要删除的数据ID
//     * @return 结果
//     */
//    public int deleteGenTableColumnByIds(Long[] ids);
}
